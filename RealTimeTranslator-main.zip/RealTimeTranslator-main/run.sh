#!/bin/bash
# Script de lancement du traducteur audio en temps réel

echo "🚀 Lancement du traducteur audio..."
echo ""

# Active l'environnement virtuel et lance le programme
./venv/bin/python3 audio_translator.py
