# Traducteur Audio en Temps Reel

Capture l'audio systeme (anglais) et joue la traduction francaise en temps reel, comme un **doublage en direct**.

## Fonctionnalites

- Capture l'audio systeme via un peripherique loopback/monitor
- Reconnaissance vocale locale avec **Faster-Whisper** (support GPU CUDA)
- Traduction anglais vers francais via **Google Translate** (deep-translator)
- Synthese vocale francaise avec **Piper TTS** (fallback: espeak-ng)
- Calibration automatique du seuil de silence au demarrage
- Raccourcis clavier pour controler la traduction en cours
- Lecture audio interruptible via pygame

## Comment ca marche

```
Audio systeme (anglais) --> Capture via PyAudio (loopback/monitor)
        |
        v
Detection de parole (seuil RMS calibre automatiquement)
        |
        v
Silence detecte (2s) --> Phrase complete
        |
        v
Faster-Whisper (reconnaissance locale, GPU ou CPU)
        |
        v
deep-translator (Google Translate EN -> FR)
        |
        v
Piper TTS (synthese vocale francaise, fallback espeak-ng)
        |
        v
Lecture audio avec volume +15dB (pygame)
```

La traduction et la synthese vocale sont executees en parallele pour minimiser la latence.

## Prerequis systeme

- Linux avec PulseAudio
- Python 3.8+
- Peripherique de capture audio (loopback/monitor)
- Connexion internet (pour Google Translate)
- (Optionnel) GPU NVIDIA compatible CUDA pour accelerer la reconnaissance vocale

## Installation

```bash
# 1. Rendre les scripts executables
chmod +x install.sh run.sh

# 2. Lancer l'installation (dependances systeme + environnement virtuel Python)
./install.sh
```

Le script `install.sh` installe :
- Les paquets systeme : `portaudio19-dev`, `python3-pyaudio`, `ffmpeg`, `pulseaudio`, `pavucontrol`
- Un environnement virtuel Python avec les dependances du projet

**Note :** Le fichier `requirements.txt` actuel est desynchronise avec le code. Les dependances reellement utilisees sont :

| Dependance | Usage |
|---|---|
| `pyaudio` | Capture audio systeme |
| `SpeechRecognition` | Interface reconnaissance vocale |
| `deep-translator` | Traduction Google Translate |
| `pydub` | Manipulation audio (conversion, volume) |
| `faster-whisper` | Reconnaissance vocale locale (remplace openai-whisper) |
| `torch` | Detection GPU pour Faster-Whisper |
| `numpy` | Traitement de donnees audio |
| `piper-tts` | Synthese vocale francaise haute qualite |
| `pynput` | Ecoute des raccourcis clavier |
| `pygame` | Lecture audio interruptible |

## Lancement

```bash
./run.sh
```

Ou manuellement :

```bash
source venv/bin/activate
python3 audio_translator.py
```

## Utilisation

### Demarrage

1. Le programme charge le modele Whisper (`tiny` sur CPU, `base` sur GPU)
2. Il telecharge automatiquement le modele vocal Piper francais (`fr_FR-siwis-medium` ou `high`) s'il n'est pas present
3. La liste des peripheriques audio s'affiche
4. Tu selectionnes le peripherique de capture :
   - Cherche un peripherique avec **"monitor"** ou **"loopback"** dans le nom
   - Ou entre **-1** pour le peripherique par defaut
5. La calibration du seuil de silence se lance automatiquement (3 secondes sans son)
6. La capture demarre

### Raccourcis clavier

| Touche | Action |
|---|---|
| `W` | Forcer la traduction immediate (sans attendre le silence) |
| `X` | Arreter la lecture en cours et reinitialiser l'enregistrement |
| `Ctrl+C` | Quitter le programme |

### Detection de phrase

Le systeme detecte automatiquement les phrases completes :
- **Seuil de silence** : calibre automatiquement au demarrage (bruit ambiant max x1.5)
- **Duree de silence requise** : 2.0 secondes pour considerer la phrase terminee
- **Duree minimale de phrase** : 1.5 secondes (evite les mots isoles)
- **Texte minimum** : 3 caracteres (ignore le bruit reconnu comme texte tres court)

### Affichage en cours d'execution

```
RMS volume en continu :
  Volume RMS:  342 | Silence | Seuil: 500

Detection de parole :
  Debut d'enregistrement (RMS: 1523)

Traduction :
  Anglais: Hello, how are you today?
  Francais: Bonjour, comment allez-vous aujourd'hui ?
  Lecture traduction (volume +15dB)
```

## Configuration

Les parametres sont definis dans la classe `AudioTranslator` ([audio_translator.py](audio_translator.py)) :

| Parametre | Valeur par defaut | Description |
|---|---|---|
| `SILENCE_THRESHOLD` | 500 (calibre au demarrage) | Seuil RMS pour detecter le silence |
| `SILENCE_DURATION` | 2.0s | Duree de silence pour terminer une phrase |
| `MIN_PHRASE_DURATION` | 1.5s | Duree minimale d'une phrase |
| `VOLUME_BOOST` | 15 dB | Augmentation du volume de la voix francaise |
| `tts_speed` | 0.7 | Vitesse de la synthese vocale (1.0 = normal) |
| `RATE` | 44100 Hz | Taux d'echantillonnage de la capture |
| `CHANNELS` | 2 | Nombre de canaux audio captures |

## Technologies

- **[Faster-Whisper](https://github.com/SYSTRAN/faster-whisper)** : Reconnaissance vocale locale (4x plus rapide que Whisper standard), support GPU CUDA et CPU (int8)
- **[deep-translator](https://github.com/nidhaloff/deep-translator)** : Traduction via Google Translate
- **[Piper TTS](https://github.com/rhasspy/piper)** : Synthese vocale francaise locale de haute qualite (modele `fr_FR-siwis-medium/high`)
- **[espeak-ng](https://github.com/espeak-ng/espeak-ng)** : Fallback TTS si Piper n'est pas disponible
- **[PyAudio](https://pypi.org/project/PyAudio/)** : Capture audio systeme
- **[pydub](https://github.com/jiaaro/pydub)** : Manipulation audio (conversion, boost volume)
- **[pygame](https://www.pygame.org/)** : Lecture audio interruptible
- **[pynput](https://github.com/moses-palmer/pynput)** : Ecoute des raccourcis clavier

## Depannage

**Pas de son francais ?**
- Verifie que le volume systeme n'est pas a 0
- Verifie que pygame est installe (`pip install pygame`)
- Verifie les logs pour voir quel moteur TTS est utilise (piper ou espeak-ng)

**Traduction trop lente ?**
- Reduis `SILENCE_DURATION` dans [audio_translator.py:48](audio_translator.py#L48) (actuellement 2.0s)
- Reduis `MIN_PHRASE_DURATION` dans [audio_translator.py:49](audio_translator.py#L49) (actuellement 1.5s)
- Utilise un GPU NVIDIA pour accelerer la reconnaissance Whisper

**L'audio n'est pas capture ?**
- Utilise `pavucontrol` pour verifier la source de capture
- Selectionne un peripherique **"monitor"** dans la liste au demarrage
- Verifie que PulseAudio est actif : `pulseaudio --check`

**Le modele Piper ne se telecharge pas ?**
- Verifie ta connexion internet
- Le modele est telecharge dans `~/.local/share/piper-voices/`
- En fallback, le programme utilise `espeak-ng` (installer avec `sudo apt install espeak-ng`)

**Erreur GPU ?**
- Le programme detecte automatiquement le GPU et bascule sur CPU si incompatible
- Pour forcer le CPU, le programme utilise `tiny` (modele plus leger) automatiquement

## Cas d'usage

- Regarder des videos YouTube en anglais avec doublage francais en direct
- Suivre des conferences ou webinars en anglais
- Ecouter des podcasts anglais traduits en francais
- Jouer a des jeux video en anglais avec traduction audio

## Architecture du code

Le fichier principal [audio_translator.py](audio_translator.py) contient la classe `AudioTranslator` avec :

- `__init__` : Initialisation (Whisper, traducteur, detection GPU)
- `setup_piper_tts` : Configuration et telechargement du modele vocal Piper
- `list_audio_devices` / `select_loopback_device` : Selection du peripherique audio
- `calibrate_silence_threshold` : Calibration automatique du seuil de silence
- `capture_audio` : Thread de capture audio en continu
- `recognize_and_translate` : Thread principal de detection de phrase, reconnaissance et traduction
- `process_complete_phrase` : Traitement d'une phrase (Whisper + traduction + TTS en parallele)
- `play_audio_interruptible` : Lecture audio via pygame (interruptible avec touche X)
- `on_key_press` : Gestionnaire des raccourcis clavier (W/X)
- `start` : Point d'entree qui orchestre les threads
