#!/usr/bin/env python3
"""
Programme de traduction audio en temps réel
Capture l'audio système (anglais) et joue la traduction française
"""

import sys
import time
import threading
import queue
from io import BytesIO
import pyaudio
import speech_recognition as sr
from deep_translator import GoogleTranslator
import pyttsx3
from pydub import AudioSegment
import subprocess
from pydub.playback import play
import tempfile
import os
import wave
from faster_whisper import WhisperModel
import numpy as np
from pynput import keyboard

class AudioTranslator:
    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.translator = GoogleTranslator(source='en', target='fr')
        self.audio_queue = queue.Queue()
        self.running = False
        self.is_playing_translation = False  # Flag pour éviter de capter notre propre traduction
        self.stop_playback = False  # Flag pour arrêter la lecture (flèche droite)
        self.force_translation = False  # Flag pour forcer la traduction (flèche gauche)
        self.reset_recording = False  # Flag pour réinitialiser l'enregistrement (flèche droite)
        self.playback_thread = None  # Thread de lecture audio

        # Configuration audio
        self.CHUNK = 1024
        self.FORMAT = pyaudio.paInt16
        self.CHANNELS = 2
        self.RATE = 44100
        self.RECORD_SECONDS = 0.1  # Durée d'écoute par segment - RÉDUIT pour détection rapide du silence
        self.VOLUME_BOOST = 15  # Augmentation du volume en dB pour la voix française (augmenté pour clarté)

        # Configuration détection de silence
        self.SILENCE_THRESHOLD = 500  # Seuil RMS pour détecter le silence (sera calibré au démarrage)
        self.SILENCE_DURATION = 2.0  # Durée de silence (en secondes) pour considérer la phrase finie - RÉDUIT POUR PLUS DE RAPIDITÉ
        self.MIN_PHRASE_DURATION = 1.5  # Durée minimale d'une phrase (en secondes) - Évite les mots isolés
        self.MAX_PHRASE_DURATION = 999999  # Pas de timeout - attend le silence

        print("🎧 Initialisation du traducteur audio...")
        print("📌 Langue source: Anglais")
        print("📌 Langue cible: Français")

        # Charge le modèle Whisper (base = bon compromis vitesse/qualité)
        print("🤖 Chargement du modèle Whisper (local, rapide)...")

        # Détecte si un GPU est disponible
        import torch

        # Vérifie la compatibilité GPU
        gpu_compatible = False
        if torch.cuda.is_available():
            try:
                # Test si le GPU est compatible en créant un petit tenseur
                test_tensor = torch.zeros(1, device="cuda")
                gpu_compatible = True
                print(f"🚀 GPU détecté: {torch.cuda.get_device_name(0)}")
                print("⚡ Utilisation du GPU pour une reconnaissance ultra-rapide!")
            except Exception as e:
                print(f"⚠️  GPU détecté ({torch.cuda.get_device_name(0)}) mais non compatible avec PyTorch")
                print("💻 Utilisation du CPU à la place")
        else:
            print("💻 Utilisation du CPU (pas de GPU NVIDIA détecté)")

        self.device = "cuda" if gpu_compatible else "cpu"
        self.use_fp16 = False  # Désactiver FP16 pour éviter les problèmes

        # Utilise "tiny" (4x plus rapide) au lieu de "base" sur CPU
        model_size = "base" if gpu_compatible else "tiny"
        # Utilise faster-whisper (4x plus rapide que Whisper standard)
        compute_type = "float16" if gpu_compatible else "int8"
        self.whisper_model = WhisperModel(model_size, device=self.device, compute_type=compute_type)
        print(f"✅ Faster-Whisper prêt! (modèle: {model_size}, compute: {compute_type})")

        # Configuration TTS avec piper (voix de haute qualité)
        self.tts_speed = 0.7  # Vitesse de parole (1.0 = normal, 0.7 = plus lent pour clarté maximale)
        self.setup_piper_tts()

    def setup_piper_tts(self):
        """Configure piper-tts avec un modèle français de qualité"""
        import urllib.request

        # Répertoire pour les modèles piper
        models_dir = os.path.join(os.path.expanduser("~"), ".local", "share", "piper-voices")
        os.makedirs(models_dir, exist_ok=True)

        # Modèle français de qualité supérieure (qualité maximale)
        # Essayer d'abord le modèle high, sinon medium
        model_name = "fr_FR-siwis-medium"
        model_name_high = "fr_FR-siwis-high"
        
        # Essayer d'abord le modèle high (meilleure qualité)
        high_model_path = os.path.join(models_dir, f"{model_name_high}.onnx")
        high_config_path = os.path.join(models_dir, f"{model_name_high}.onnx.json")
        
        if os.path.exists(high_model_path):
            model_name = model_name_high
            print(f"✨ Modèle haute qualité trouvé: {model_name}")
        
        self.piper_model_path = os.path.join(models_dir, f"{model_name}.onnx")
        self.piper_config_path = os.path.join(models_dir, f"{model_name}.onnx.json")

        # URLs de téléchargement - utiliser la version la plus récente
        base_url = "https://github.com/rhasspy/piper/releases/download/v1.2.0"
        model_url = f"{base_url}/{model_name}.onnx"
        config_url = f"{base_url}/{model_name}.onnx.json"

        # Télécharge le modèle si nécessaire
        if not os.path.exists(self.piper_model_path):
            print(f"📥 Téléchargement du modèle vocal français de qualité supérieure...")
            try:
                # Essayer la version récente d'abord
                try:
                    urllib.request.urlretrieve(model_url, self.piper_model_path)
                    urllib.request.urlretrieve(config_url, self.piper_config_path)
                    print(f"✅ Modèle téléchargé: {model_name} (qualité supérieure)")
                except:
                    # Fallback sur l'ancienne version si la nouvelle n'existe pas
                    base_url_old = "https://github.com/rhasspy/piper/releases/download/v0.0.2"
                    model_url_old = f"{base_url_old}/{model_name}.onnx"
                    config_url_old = f"{base_url_old}/{model_name}.onnx.json"
                    urllib.request.urlretrieve(model_url_old, self.piper_model_path)
                    urllib.request.urlretrieve(config_url_old, self.piper_config_path)
                    print(f"✅ Modèle téléchargé: {model_name}")
            except Exception as e:
                print(f"⚠️  Erreur téléchargement modèle: {e}")
                print(f"💡 Utilisation de espeak-ng en fallback")
                self.piper_model_path = None
        else:
            print(f"✅ Modèle vocal piper chargé: {model_name} (haute qualité)")

        # Initialise piper
        if self.piper_model_path and os.path.exists(self.piper_model_path):
            try:
                from piper import PiperVoice
                self.piper_voice = PiperVoice.load(self.piper_model_path, config_path=self.piper_config_path)
                print(f"🎙️  Voix piper prête (vitesse: {self.tts_speed}x)")
            except Exception as e:
                print(f"⚠️  Erreur chargement piper: {e}")
                self.piper_voice = None
        else:
            self.piper_voice = None

    def list_audio_devices(self):
        """Liste tous les périphériques audio disponibles"""
        p = pyaudio.PyAudio()
        print("\n🔊 Périphériques audio disponibles:")
        print("-" * 60)

        device_count = p.get_device_count()
        for i in range(device_count):
            info = p.get_device_info_by_index(i)
            print(f"ID {i}: {info['name']}")
            print(f"  Canaux entrée: {info['maxInputChannels']}")
            print(f"  Canaux sortie: {info['maxOutputChannels']}")
            print(f"  Taux d'échantillonnage: {int(info['defaultSampleRate'])} Hz")
            print("-" * 60)

        p.terminate()
        return device_count

    def select_loopback_device(self):
        """Aide l'utilisateur à sélectionner le périphérique de loopback"""
        device_count = self.list_audio_devices()

        print("\n💡 Pour capturer l'audio système sur Linux:")
        print("1. Cherche un périphérique avec 'monitor' ou 'loopback' dans le nom")
        print("2. Ou utilise 'pavucontrol' pour configurer PulseAudio")
        print("3. Entre -1 pour utiliser le périphérique par défaut")

        while True:
            try:
                device_id = input("\n🎤 Entre l'ID du périphérique à utiliser: ")
                if device_id.strip() == "-1":
                    return None
                device_id = int(device_id)
                if 0 <= device_id < device_count:
                    return device_id
                print(f"❌ ID invalide. Choisis entre 0 et {device_count - 1}")
            except ValueError:
                print("❌ Entre un nombre valide ou -1")

    def calibrate_silence_threshold(self, device_index=None):
        """Calibre le seuil de silence en mesurant le bruit ambiant"""
        print("\n🎚️  Calibration du seuil de silence...")
        print("📍 Assure-toi qu'aucun son ne joue pendant 3 secondes...")
        time.sleep(1)

        p = pyaudio.PyAudio()
        rms_values = []

        try:
            stream = p.open(
                format=self.FORMAT,
                channels=self.CHANNELS,
                rate=self.RATE,
                input=True,
                input_device_index=device_index,
                frames_per_buffer=self.CHUNK
            )

            # Mesure le bruit ambiant pendant 3 secondes
            calibration_duration = 3.0
            num_samples = int(calibration_duration / self.RECORD_SECONDS)

            for i in range(num_samples):
                frames = []
                for _ in range(0, int(self.RATE / self.CHUNK * self.RECORD_SECONDS)):
                    data = stream.read(self.CHUNK, exception_on_overflow=False)
                    frames.append(data)

                audio_data = b''.join(frames)
                audio_segment = AudioSegment(
                    data=audio_data,
                    sample_width=2,
                    frame_rate=self.RATE,
                    channels=self.CHANNELS
                )
                rms_values.append(audio_segment.rms)
                print(f"⏳ Calibration... {i+1}/{num_samples} (RMS: {audio_segment.rms})", end="\r")

            stream.stop_stream()
            stream.close()

            # Calcule le seuil: moyenne + 3x écart-type pour être sûr
            avg_rms = sum(rms_values) / len(rms_values)
            max_rms = max(rms_values)
            # Ajoute une marge de 50% au-dessus du maximum mesuré
            self.SILENCE_THRESHOLD = int(max_rms * 1.5)

            print(f"\n✅ Calibration terminée!")
            print(f"📊 Bruit ambiant moyen: {int(avg_rms)} RMS")
            print(f"📊 Bruit ambiant max: {max_rms} RMS")
            print(f"🎯 Seuil défini à: {self.SILENCE_THRESHOLD} RMS")

        except Exception as e:
            print(f"\n⚠️  Erreur de calibration: {e}")
            print(f"📌 Utilisation du seuil par défaut: {self.SILENCE_THRESHOLD}")
        finally:
            p.terminate()

    def capture_audio(self, device_index=None):
        """Capture l'audio système en continu"""
        p = pyaudio.PyAudio()

        try:
            stream = p.open(
                format=self.FORMAT,
                channels=self.CHANNELS,
                rate=self.RATE,
                input=True,
                input_device_index=device_index,
                frames_per_buffer=self.CHUNK
            )

            print("\n✅ Capture audio démarrée!")
            print("🎯 En attente de parole anglaise...")
            print("⏹️  Appuie sur Ctrl+C pour arrêter\n")

            while self.running:
                frames = []
                for _ in range(0, int(self.RATE / self.CHUNK * self.RECORD_SECONDS)):
                    if not self.running:
                        break
                    data = stream.read(self.CHUNK, exception_on_overflow=False)
                    frames.append(data)

                if frames:
                    audio_data = b''.join(frames)
                    self.audio_queue.put(audio_data)

            stream.stop_stream()
            stream.close()

        except Exception as e:
            print(f"❌ Erreur de capture audio: {e}")
        finally:
            p.terminate()

    def recognize_and_translate(self):
        """Reconnaît la parole et traduit en continu avec détection de silence"""
        print("🔄 Thread de reconnaissance démarré")
        print(f"🎯 Détection de silence activée (seuil: {self.SILENCE_THRESHOLD} RMS)\n")

        chunk_count = 0
        accumulated_audio = []
        silence_chunks = 0
        is_speaking = False
        phrase_start_time = None
        last_display_time = time.time()  # Pour afficher le RMS toutes les secondes

        while self.running:
            try:
                # Récupère l'audio de la queue avec timeout
                audio_data = self.audio_queue.get(timeout=1)
                chunk_count += 1

                # Convertit en format compatible avec speech_recognition
                audio_segment = AudioSegment(
                    data=audio_data,
                    sample_width=2,  # 16-bit
                    frame_rate=self.RATE,
                    channels=self.CHANNELS
                )

                # Calcule le niveau audio (RMS)
                rms = audio_segment.rms

                # Affiche le RMS toutes les secondes
                current_time = time.time()
                if current_time - last_display_time >= 1.0:
                    if self.is_playing_translation:
                        status = "🔊 Traduction en cours"
                    elif is_speaking:
                        status = "🗣️ PAROLE"
                    else:
                        status = "🔇 Silence"
                    print(f"📊 Volume RMS: {rms:4d} | {status} | Seuil: {self.SILENCE_THRESHOLD}")
                    last_display_time = current_time

                # Vérifier si l'utilisateur a appuyé sur P pour réinitialiser (AVANT tout)
                if self.reset_recording:
                    if is_speaking or accumulated_audio:
                        print(f"\n🔄 Réinitialisation de l'enregistrement (flèche droite)")
                        accumulated_audio = []
                        silence_chunks = 0
                        is_speaking = False
                        phrase_start_time = None
                    self.reset_recording = False
                    continue

                # Ignore l'audio quand on joue la traduction (pour éviter la boucle)
                if self.is_playing_translation:
                    continue

                # Vérifier si l'utilisateur a appuyé sur O pour forcer la traduction
                if self.force_translation and is_speaking and accumulated_audio:
                    print(f"\n⚡ Traduction forcée par l'utilisateur (flèche gauche)")

                    # Combine tous les chunks audio
                    combined_audio = b''.join(accumulated_audio)

                    # Traite la phrase complète
                    self.process_complete_phrase(combined_audio)

                    # Réinitialise
                    accumulated_audio = []
                    silence_chunks = 0
                    is_speaking = False
                    phrase_start_time = None
                    self.force_translation = False
                    continue

                # Détection de parole vs silence
                if rms > self.SILENCE_THRESHOLD:
                    # Quelqu'un parle
                    if not is_speaking:
                        is_speaking = True
                        phrase_start_time = time.time()
                        print(f"\n🎤 Début d'enregistrement (RMS: {rms})")
                    elif silence_chunks > 0:
                        # DEBUG: Bruit qui réinitialise le compteur de silence
                        print(f"\n⚠️  BRUIT détecté (RMS: {rms}) - Compteur silence réinitialisé de {silence_chunks} à 0")

                    accumulated_audio.append(audio_data)
                    silence_chunks = 0
                else:
                    # Silence
                    if is_speaking:
                        silence_chunks += 1
                        accumulated_audio.append(audio_data)

                        # DEBUG: Affiche chaque chunk de silence
                        print(f"🔇 Silence chunk {silence_chunks} (RMS: {rms})", end="\r")

                        # Calcule la durée du silence (chaque chunk = RECORD_SECONDS secondes)
                        chunk_duration = self.RECORD_SECONDS
                        silence_duration = silence_chunks * chunk_duration

                        # Si assez de silence ET phrase assez longue
                        if silence_duration >= self.SILENCE_DURATION:
                            phrase_duration = time.time() - phrase_start_time

                            if phrase_duration >= self.MIN_PHRASE_DURATION:
                                print(f"\n✅ Phrase complète détectée! (durée: {phrase_duration:.1f}s)")

                                # Combine tous les chunks audio
                                combined_audio = b''.join(accumulated_audio)

                                # Traite la phrase complète
                                self.process_complete_phrase(combined_audio)

                            # Réinitialise
                            accumulated_audio = []
                            silence_chunks = 0
                            is_speaking = False
                            phrase_start_time = None
                    else:
                        print(f"📊 Silence - Niveau: {rms}", end="\r")

                # Timeout: Si on enregistre depuis trop longtemps, force la traduction
                if is_speaking and phrase_start_time:
                    phrase_duration = time.time() - phrase_start_time
                    if phrase_duration >= self.MAX_PHRASE_DURATION:
                        print(f"\n⏱️  Timeout atteint! ({phrase_duration:.1f}s) - Traduction forcée...")

                        # Combine tous les chunks audio
                        combined_audio = b''.join(accumulated_audio)

                        # Traite la phrase complète
                        self.process_complete_phrase(combined_audio)

                        # Réinitialise
                        accumulated_audio = []
                        silence_chunks = 0
                        is_speaking = False
                        phrase_start_time = None

            except queue.Empty:
                continue
            except Exception as e:
                if self.running:
                    print(f"\n❌ Erreur: {e}")

    def clean_recognized_text(self, text):
        """Nettoie et améliore le texte reconnu par Google Speech"""
        import re

        # Détecte les questions à choix multiples (a/be/see/d)
        # Pattern: "a something be something else see another thing d final thing"

        # Remplace les patterns de choix multiples
        text = re.sub(r'\ba\s+', 'A) ', text, count=1)  # Premier "a" → "A)"
        text = re.sub(r'\s+be\s+', ' B) ', text, count=1)  # "be" → "B)"
        text = re.sub(r'\s+see\s+', ' C) ', text, count=1)  # "see" → "C)"
        text = re.sub(r'\s+d\s+', ' D) ', text, count=1)  # "d" → "D)"

        # Corrections courantes de reconnaissance vocale
        corrections = {
            'dark': 'docked',  # Contexte aéroport
            ' to ': ' two ',
            ' for ': ' four ',
        }

        for wrong, right in corrections.items():
            if wrong in text.lower():
                # Applique la correction en gardant la casse
                text = re.sub(re.escape(wrong), right, text, flags=re.IGNORECASE)

        return text

    def process_complete_phrase(self, audio_data):
        """Traite une phrase complète détectée avec Whisper + traduction parallèle"""
        try:
            # Convertit en AudioSegment
            audio_segment = AudioSegment(
                data=audio_data,
                sample_width=2,
                frame_rate=self.RATE,
                channels=self.CHANNELS
            ).set_channels(1)

            # Exporte en WAV temporaire
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp_file:
                audio_segment.export(tmp_file.name, format='wav')
                tmp_path = tmp_file.name

            try:
                # ⚡ FASTER-WHISPER - RECONNAISSANCE LOCALE ULTRA-RAPIDE
                device_label = "GPU" if self.device == "cuda" else "CPU"
                print(f"🔍 Reconnaissance Faster-Whisper ({device_label})...")
                start_time = time.time()

                # faster-whisper retourne (segments, info)
                segments, info = self.whisper_model.transcribe(
                    tmp_path,
                    language='en'
                )
                # Combine tous les segments en un seul texte
                text_en = " ".join([segment.text for segment in segments]).strip()

                recognition_time = time.time() - start_time
                print(f"⚡ Reconnaissance: {recognition_time:.2f}s ({device_label})")

                os.unlink(tmp_path)

                if text_en:
                    # Nettoie et améliore le texte reconnu
                    text_en_clean = self.clean_recognized_text(text_en)

                    # Ignore les phrases trop courtes (moins de 3 caractères)
                    if len(text_en_clean.strip()) < 3:
                        print(f"⚠️  Texte trop court ignoré: '{text_en_clean}'")
                        return

                    print(f"\n🇬🇧 Anglais: {text_en_clean}")

                    # 🚀 TRADUCTION ET TTS EN PARALLÈLE
                    translation_result = [None]
                    translation_error = [None]
                    tts_audio = [None]

                    def translate_task():
                        try:
                            translation = self.translator.translate(text_en_clean)
                            translation_result[0] = translation
                            print(f"🇫🇷 Français: {translation}")
                        except Exception as e:
                            translation_error[0] = str(e)
                            print(f"❌ Erreur de traduction: {e}")

                    def tts_task():
                        # Attend que la traduction soit prête ou qu'il y ait une erreur
                        while translation_result[0] is None and translation_error[0] is None:
                            time.sleep(0.01)

                        # Si erreur de traduction, ne génère pas le TTS
                        if translation_error[0] is not None:
                            return

                        # Utilise TTS local pour vitesse < 1s (voix piper optimisée)
                        tts_start = time.time()
                        success = False

                        # Priorité 1: Piper (rapide < 1s, qualité optimisée)
                        if hasattr(self, 'piper_voice') and self.piper_voice is not None:
                            try:
                                from piper import SynthesisConfig
                                
                                with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp:
                                    # Paramètres optimisés pour clarté maximale et qualité vocale
                                    length_scale = 1.0 / self.tts_speed if self.tts_speed > 0 else 1.0
                                    syn_config = SynthesisConfig(
                                        length_scale=length_scale,
                                        noise_scale=0.5,      # Bruit minimal pour clarté maximale
                                        noise_w_scale=0.7,    # Très stable pour mots clairs
                                        normalize_audio=True, # Normalisation pour qualité maximale
                                        volume=1.2            # Volume légèrement augmenté dans le modèle
                                    )
                                    
                                    with wave.open(tmp.name, 'wb') as wav_file:
                                        self.piper_voice.synthesize_wav(
                                            translation_result[0],
                                            wav_file,
                                            syn_config=syn_config
                                        )
                                    tts_audio[0] = tmp.name
                                    tts_time = time.time() - tts_start
                                    print(f"🎤 TTS généré en {tts_time:.2f}s (piper - qualité optimisée)")
                                    success = True
                            except Exception as e:
                                print(f"⚠️  Erreur piper: {e}")

                        # Fallback 2: espeak-ng/espeak (qualité basique mais très rapide)
                        if not success:
                            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp:
                                # Calcule la vitesse pour espeak (mots par minute)
                                espeak_speed = int(165 * self.tts_speed)

                                try:
                                    subprocess.run(
                                        ['espeak-ng', '-v', 'fr', '-s', str(espeak_speed), '-w', tmp.name, translation_result[0]],
                                        check=True,
                                        capture_output=True,
                                        timeout=2
                                    )
                                    tts_audio[0] = tmp.name
                                    tts_time = time.time() - tts_start
                                    print(f"🎤 TTS généré en {tts_time:.2f}s (espeak-ng)")
                                    success = True
                                except (FileNotFoundError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
                                    try:
                                        subprocess.run(
                                            ['espeak', '-v', 'fr', '-s', str(espeak_speed), '-w', tmp.name, translation_result[0]],
                                            check=True,
                                            capture_output=True,
                                            timeout=2
                                        )
                                        tts_audio[0] = tmp.name
                                        tts_time = time.time() - tts_start
                                        print(f"🎤 TTS généré en {tts_time:.2f}s (espeak)")
                                        success = True
                                    except:
                                        pass

                                if not success:
                                    print(f"⚠️  Aucun moteur TTS disponible!")
                                    print(f"💡 Installe piper-tts (déjà fait) ou espeak-ng: sudo apt install espeak-ng")
                                    tts_audio[0] = None

                    # Lance traduction et TTS en parallèle
                    translate_thread = threading.Thread(target=translate_task)
                    tts_thread = threading.Thread(target=tts_task)

                    translate_thread.start()
                    tts_thread.start()

                    translate_thread.join()
                    tts_thread.join()

                    # Joue l'audio
                    if tts_audio[0]:
                        # Charge le fichier audio WAV (piper/espeak)
                        audio = AudioSegment.from_wav(tts_audio[0])
                        audio = audio + self.VOLUME_BOOST

                        print(f"🔊 Lecture traduction (volume +{self.VOLUME_BOOST}dB)")
                        self.is_playing_translation = True
                        self.stop_playback = False
                        self.play_audio_interruptible(audio)
                        time.sleep(0.5)
                        self.is_playing_translation = False

                        os.unlink(tts_audio[0])
                else:
                    print("⚠️  Pas de parole claire détectée")

            except Exception as e:
                print(f"❌ Erreur de reconnaissance: {e}")

        except Exception as e:
            print(f"❌ Erreur de traitement: {e}")

    def play_audio_interruptible(self, audio_segment):
        """Joue l'audio avec pygame pour permettre l'interruption"""
        import pygame

        # Initialise pygame mixer si nécessaire
        if not pygame.mixer.get_init():
            pygame.mixer.init(frequency=22050)

        # Sauvegarde l'audio dans un fichier temporaire
        with tempfile.NamedTemporaryFile(suffix='.mp3', delete=False) as tmp_file:
            audio_segment.export(tmp_file.name, format='mp3')
            tmp_path = tmp_file.name

        try:
            # Charge et joue l'audio
            pygame.mixer.music.load(tmp_path)
            pygame.mixer.music.play()

            # Attend la fin de la lecture ou l'interruption
            while pygame.mixer.music.get_busy():
                if self.stop_playback:
                    pygame.mixer.music.stop()
                    print("\n⏹️  Lecture interrompue (flèche droite)")
                    break
                time.sleep(0.1)
        finally:
            # Nettoie
            try:
                os.unlink(tmp_path)
            except:
                pass

    def play_translation(self, text):
        """Convertit le texte en parole et le joue (fonction legacy - non utilisée)"""
        try:
            # Génère l'audio avec gTTS
            from gtts import gTTS
            tts = gTTS(text=text, lang='fr', slow=False)

            # Sauvegarde dans un fichier temporaire
            with tempfile.NamedTemporaryFile(suffix='.mp3', delete=False) as tmp_file:
                tts.save(tmp_file.name)
                tmp_path = tmp_file.name

            # Charge l'audio et augmente le volume
            audio = AudioSegment.from_mp3(tmp_path)
            audio = audio + self.VOLUME_BOOST  # Augmente le volume de X dB

            print(f"🔊 Lecture traduction (volume +{self.VOLUME_BOOST}dB)")

            # Active le flag pour ignorer la capture pendant qu'on joue
            self.is_playing_translation = True
            play(audio)
            # Attends un peu après la fin pour être sûr
            time.sleep(0.5)
            self.is_playing_translation = False

            # Supprime le fichier temporaire
            os.unlink(tmp_path)

        except Exception as e:
            print(f"❌ Erreur de lecture audio: {e}")
            self.is_playing_translation = False  # Désactive même en cas d'erreur

    def on_key_press(self, key):
        """Gestionnaire d'événements pour les touches pressées"""
        try:
            # Touche x : arrête la lecture et réinitialise l'enregistrement (anciennement flèche droite)
            if hasattr(key, 'char') and key.char == 'x':
                self.stop_playback = True
                self.reset_recording = True
                print("\n🛑 Touche X détectée - Arrêt et réinitialisation")
            # Touche w : force la traduction immédiate (anciennement flèche gauche)
            elif hasattr(key, 'char') and key.char == 'w':
                self.force_translation = True
                print("\n⚡ Touche W détectée - Traduction immédiate")
        except AttributeError:
            pass

    def start(self, device_index=None):
        """Démarre le traducteur"""
        # Calibre le seuil de silence avant de commencer
        self.calibrate_silence_threshold(device_index)

        self.running = True

        # Thread de capture audio
        capture_thread = threading.Thread(
            target=self.capture_audio,
            args=(device_index,),
            daemon=True
        )

        # Thread de reconnaissance et traduction
        translate_thread = threading.Thread(
            target=self.recognize_and_translate,
            daemon=True
        )

        capture_thread.start()
        translate_thread.start()

        # Démarre le listener de clavier
        listener = keyboard.Listener(on_press=self.on_key_press)
        listener.start()

        print("\n⌨️  Raccourcis clavier:")
        print("  - Touche X : Arrêter la lecture et réinitialiser l'enregistrement")
        print("  - Touche W : Forcer la traduction immédiate")
        print("  - Ctrl+C : Quitter\n")


        try:
            # Garde le programme actif
            while True:
                time.sleep(0.1)
        except KeyboardInterrupt:
            print("\n\n🛑 Arrêt du traducteur...")
            self.running = False
            listener.stop()
            capture_thread.join(timeout=2)
            translate_thread.join(timeout=2)
            print("✅ Terminé!")

def main():
    print("=" * 60)
    print("🎙️  TRADUCTEUR AUDIO EN TEMPS RÉEL 🎙️")
    print("     Anglais → Français")
    print("=" * 60)

    translator = AudioTranslator()

    # Demande à l'utilisateur de sélectionner le périphérique
    device_index = translator.select_loopback_device()

    # Démarre la traduction
    translator.start(device_index)

if __name__ == "__main__":
    main()
