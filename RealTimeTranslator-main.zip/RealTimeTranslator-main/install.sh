#!/bin/bash
# Script d'installation automatique pour le traducteur audio

echo "============================================================"
echo "🎙️  Installation du Traducteur Audio en Temps Réel"
echo "============================================================"
echo ""

# Vérification Ubuntu
if ! grep -q "Ubuntu" /etc/os-release 2>/dev/null; then
    echo "⚠️  Attention: Ce script est optimisé pour Ubuntu"
    read -p "Continuer quand même? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

echo "📦 Installation des dépendances système..."
sudo apt update
sudo apt install -y python3 python3-pip python3-venv portaudio19-dev python3-pyaudio ffmpeg pulseaudio pavucontrol

echo ""
echo "🔧 Création de l'environnement virtuel Python..."
python3 -m venv venv

echo ""
echo "🐍 Installation des bibliothèques Python dans l'environnement virtuel..."
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
deactivate

echo ""
echo "✅ Installation terminée!"
echo ""
echo "============================================================"
echo "🚀 Pour lancer le programme:"
echo "   ./run.sh"
echo ""
echo "Ou manuellement:"
echo "   source venv/bin/activate"
echo "   python3 audio_translator.py"
echo ""
echo "📖 Lis le README.md pour plus d'infos:"
echo "   cat README.md"
echo "============================================================"
